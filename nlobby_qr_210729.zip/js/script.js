$(document).ready(function(){
  const check = $(".switch input[type='checkbox']");
    check.click(function(){
  });
});